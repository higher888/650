#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <malloc.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
/*creating the first pipe between rgen and a1-ece650.py*/
	int fds_12[2]; //data written to the file descriptor read [0] can be read back from write [1]
	int fds_23[2];
	char buf[100];

	int pid_rgen;
	int pid_a1;
	int pid_a2; 
	int pidf1;
	int pidf2;
	int pidf3;

	pipe (fds_12);  //create pipes
	pipe (fds_23);
	pid_rgen = fork();  //fork a child process for rgen.c
	
	if (pid_rgen > 0) {
	/*change the parent process to rgen*/
		pidf1 = getpid();
 		close (fds_12[0]);
		dup2 (fds_12[1],STDOUT_FILENO); //replace the standard output by the write end of the pipe, so that rgen output can be directly sent to write end of pipe
	
		execv ("rgen",argv); //replace the child process with the "sort" program, so that the rgen generate the output.
		
	}
	else{
		/*spawn the second child process from the first child process*/
		pid_a1 = fork();
		if (pid_a1>0){
		//this process is used to transfer data
			pidf2 = getpid();
			//wait for s instruction at the stdin for a2-ece650
			while(fgets(buf,100,stdin)!=NULL)
			{
				write(fds_23[1],buf,strlen(buf));
			}
		//if the data transfer is ended, that is while stopped,kill all these processes
			kill(pidf1,SIGKILL);
			kill(pidf2,SIGKILL);
			kill(pidf3,SIGKILL);
		}
		else
		{
			//create the third child process, then the second process and the third process are used for a1 and a2 respectively.
			pid_a2 = fork();
			if (pid_a2 >0){
				pidf2 = getpid();
				//connect the a1.py:Stdin to rgen,stdout to a2 
				close(fds_12[1]);
				close(fds_23[0]);
				dup2(fds_12[0],STDIN_FILENO);
				dup2(fds_23[1],STDOUT_FILENO);
				execl ("/usr/bin/python","/usr/bin/python","./a1-ece650.py",(char *)NULL);	
			}
			else
			{
				pidf3 = getpid();
				close(fds_23[1]);
				dup2(fds_23[0],STDIN_FILENO);
				execlp ("./a2-ece650","a2-ece650",NULL);	

			}

		}
			
		
	}

	
	return 1;
}



