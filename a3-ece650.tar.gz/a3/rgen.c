#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>

/*return a random integer between MIN and MAX,inclusive*/
int random_number (int min,int max)
{
	static int dev_random_fd = -1; //file descriptor opened to /dev/urandom
	char* next_random_byte;
	int bytes_to_read;
	unsigned random_value;
	
	/*if this is the first time this function is called, open a file descriptor to /dev/urandom*/

	if (dev_random_fd = -1){
		dev_random_fd = open ("/dev/urandom",O_RDONLY);//open for reading only
//		assert(dev_random_fd) != -1;
	}
	
	/*read enough random bytes to fill an integer variable. */
	next_random_byte = (char*) &random_value;
	bytes_to_read = sizeof (random_value);

	/*loop untile reading enough bytes*/
	do{
		int bytes_read;
		bytes_read = read (dev_random_fd,next_random_byte,bytes_to_read);
		bytes_to_read -= bytes_read;
		next_random_byte += bytes_read;
	} while (bytes_to_read > 0);
	
	/*compute a random number in the correct range.*/
	return min + (random_value % (max - min + 1));
}

/*determine whether new created edge coincide the previous generated*/
int coincide(int x11,int y11,int x12,int y12,int x13,int y13,int x14,int y14){
	float d,d1,d2,d3,d4;
	float x1 = (float) x11;
	float x2 = (float) x12;
	float x3 = (float) x13;
	float x4 = (float) x14;
	float y1 = (float) y11;
	float y2 = (float) y12;
	float y3 = (float) y13;
	float y4 = (float) y14;

	d = (y2-y1)*(x4-x3)-(y4-y3)*(x2-x1);
	d1 = (y3-y1)*(x2-x3)-(y2-y3)*(x3-x1);
	d2 = (y4-y1)*(x2-x4)-(y2-y4)*(x4-x1);
	d3 = (y1-y3)*(x4-x1)-(y4-y1)*(x1-x3);
	d4 = (y2-y3)*(x4-x2)-(y4-y2)*(x2-x3);

	if(x3 == x4 && y3 == y4){
		return 0;
	}	
	else if(x1==x3 && y1==y3 && x2==x4 && y2==y4){
		return 0;
		}
	else if (d == 0){
		if (d1 == 0 || d2 ==0 || d3 == 0 || d3==0){
			return 0;
		}

	}
	else{
		return 1;	
	}	
}

int edgeCheck(int m, int coordinate[m+2]){ 
/*determine if the two nodes are the same*/
	int i,j,c_return,temp;

//	printf("%d %d %d\n", m,coordinate[m],coordinate[m+1]);

/*determine if the edge are coincide to the other*/

	if(m == 2){
		if(coordinate[m] == coordinate[m-2] && coordinate[m-1] == coordinate[m+1]){
			return 0;
		}	
	}
	else{
	   for(i=0;i<m-2;i++){
		c_return = coincide(coordinate[i],coordinate[i+1],coordinate[i+2],coordinate[i+3],coordinate[m-2],coordinate[m-1],coordinate[m],coordinate[m+1]);
//		printf("%d",i);
		if(c_return==0){
			return 0;
		}
		
	}
	}	
	return 1;
}



int main(int argc, char* argv[])
{
	int i,j,m,n,g;
	int sleep_second;
	int k_s,k_n,k_l,k_c;
	int s_flag = 0;
	int n_flag = 0;
	int l_flag = 0;
	int c_flag = 0;
	int edgeError;
	char s1[2];
	char n1[2];
	char l1[2];
	char c1[2];
	int street_num;
	int street_num_p=0;
	int edge_num;

	strcpy(s1,"-s");
	strcpy(n1,"-n");	
	strcpy(l1,"-l");	
	strcpy(c1,"-c");

/******setting the Ks**************/
	for(i = 1;i<argc;i++){ //argc-1 is the number of arguments
//		printf("%c\n",c_temp);
		
		if(strcmp(argv[i],s1)==0){
			k_s = atoi(argv[i+1]);
			s_flag = 1;			
			}
		else if(strcmp(argv[i],n1)==0){
			k_n = atoi(argv[i+1]);
			n_flag = 1;
		}
		else if(strcmp(argv[i],l1)==0){
			k_l = atoi(argv[i+1]);
			l_flag = 1;			
			}
		else if(strcmp(argv[i],c1)==0){
			k_c = atoi(argv[i+1]);
			c_flag = 1;
		}			
	
	}

	if(s_flag==0){
	  k_s = 10;
	}
	if(n_flag==0){
	  k_n = 5;
	}
	if(l_flag==0){
	  k_l = 5;
	}
	if(c_flag==0){
	  k_c = 20;
	}

	if (k_s < 2 || k_n < 1 || k_l < 5 || k_c < 1){
		fprintf(stderr,"Error:One or more argument parameters are wrong\n");
		exit(1);
	}

//	printf("%d %d %d %d\n",k_s,k_n,k_l,k_c);	
/***************generating the streets*********************/
	
   while(1){	
	sleep_second = random_number (5,k_l);//waiting time
	street_num = random_number (2,k_s);
	edge_num = random_number (1,k_n);
		
//	printf("%d %d %d\n",sleep_second,street_num,edge_num);
	int coordinate[2*(edge_num+1)*street_num];
	m = 0;
	for(i=0;i<street_num;++i){		
		for(j=0;j<(edge_num+1);j++){
			for (n = 0; n<25; n++){
				coordinate[m] = random_number (0-k_c,k_c);
				coordinate[m+1] = random_number (0-k_c,k_c);
//				printf("%d %d %d \n",m,coordinate[m],coordinate[m+1]);

				
				if(m>0){
					edgeError = edgeCheck(m,coordinate);
					if (edgeError == 0){
						if (n == 24){
							fprintf(stderr,"Error:failed to generate valid input for 25 simultaneous attempts");
							exit(1);
						}
						else
							continue;
					}
					else{
						break;
					}				
				
				}
				else
					break;
			}

//			printf("%d", n);
			m = m + 2;			
		}
	}

//	printf("%d %d\n",street_num,edge_num);


	for(i=0;i<street_num_p;++i){
		printf("r \"street %d\"\n",i);		
	}


	m = 0;
	for(i=0;i<street_num;++i){
		printf("a \"street %d\" ",i);
		for(j=0;j<edge_num+1;j++){
			printf("(%d,%d) ",coordinate[m],coordinate[m+1]);
			m = m + 2;
		}
		printf("\n");
	}
	printf("g\n");
	fflush(stdout);

	

	sleep(sleep_second);
	
	street_num_p = street_num;
	
  }

	return 1;

}


